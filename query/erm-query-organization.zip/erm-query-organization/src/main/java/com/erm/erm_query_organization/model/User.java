package com.erm.erm_query_organization.model;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity(name = "user")
public class User extends BaseModel{
    private String email;
    private String password;

    @OneToOne
    private UserDetail userDetail;

    @OneToOne
    private Role role;
}
