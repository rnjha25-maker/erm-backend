package com.erm.erm_query_organization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErmQueryOrganizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErmQueryOrganizationApplication.class, args);
	}

}
