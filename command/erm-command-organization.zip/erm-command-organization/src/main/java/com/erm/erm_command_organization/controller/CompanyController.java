package com.erm.erm_command_organization.controller;

import com.erm.erm_command_organization.dto.requestDTO.companyDTO.AddRequest;
import com.erm.erm_command_organization.dto.requestDTO.companyDTO.UpdateRequest;
import com.erm.erm_command_organization.dto.responseDTO.GeneralResponse;
import com.erm.erm_command_organization.dto.responseDTO.ResponseStatus;
import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Company;
import com.erm.erm_command_organization.service.ICompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("company")
public class CompanyController {

    @Autowired
    private ICompanyService companyService;

    @PostMapping("/create")
    public GeneralResponse<Company> createCompany(@RequestBody AddRequest request) {
        GeneralResponse<Company> response = new GeneralResponse<>();
        Company company = companyService.createCompany(request.getName(), request.getCompanyLogoImageUrl());
        response.setData(company);
        response.setStatus(ResponseStatus.SUCCESS);
        response.setMessage("Company created!");
        return response;
    }

    @PutMapping("/update")
    public GeneralResponse<Company> updateCompany(@RequestBody UpdateRequest request) {
        GeneralResponse<Company> response = new GeneralResponse<>();
        try{
            Company company = companyService.updateCompany(request.getId(), request.getName(), request.getCompanyLogoImageUrl());
            response.setData(company);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Company updated!");
        }catch (DataNotFoundException e) {
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }

    @DeleteMapping("/{id:[\\d]+}")
    public GeneralResponse<Company> deleteCompany(@PathVariable Long id) {
        GeneralResponse<Company> response = new GeneralResponse<>();
        try{
            companyService.deleteCompany(id);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Company deleted!");
        }catch (InvalidDataException e){
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }
}
