package com.erm.erm_command_organization.controller;

import com.erm.erm_command_organization.dto.requestDTO.organizationDTO.AddRequest;
import com.erm.erm_command_organization.dto.requestDTO.organizationDTO.UpdateRequest;
import com.erm.erm_command_organization.dto.responseDTO.GeneralResponse;
import com.erm.erm_command_organization.dto.responseDTO.ResponseStatus;
import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Organization;
import com.erm.erm_command_organization.service.IOrganizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("organization")
public class OrganizationController {
    @Autowired
    private IOrganizationService organizationService;

    @PostMapping("/create")
    public GeneralResponse<Organization> createOrganization(@RequestBody AddRequest request) {
        GeneralResponse<Organization> response = new GeneralResponse<>();
        Organization organization = organizationService.createOrganization(request.getName(), request.getOrgImgUrl());
        response.setData(organization);
        response.setStatus(ResponseStatus.SUCCESS);
        response.setMessage("Organization created!");
        return response;
    }

    @PutMapping("/update")
    public GeneralResponse<Organization> updateOrganization(@RequestBody UpdateRequest request) {
        GeneralResponse<Organization> response = new GeneralResponse<>();
        try{
            Organization organization = organizationService.updateOrganization(request.getId(), request.getName(), request.getOrgImgUrl());
            response.setData(organization);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Organization updated!");
        }catch (DataNotFoundException e){
            response.setMessage(e.getMessage());
            response.setStatus(ResponseStatus.FAILED);
        }
        return response;
    }

    @DeleteMapping("/{id:[\\d]+}")
    public GeneralResponse<Void> deleteOrganization(@PathVariable Long id) {
        GeneralResponse<Void> response = new GeneralResponse<>();
        try{
            organizationService.deleteOrganization(id);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Organization deleted!");
        } catch (InvalidDataException e) {
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }
}
