package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Company;

public interface ICompanyService {
    Company createCompany(String companyName, String companyImgUrl);
    Company updateCompany(Long id, String companyName, String companyImgUrl) throws DataNotFoundException;
    void deleteCompany(Long id) throws InvalidDataException;
}
