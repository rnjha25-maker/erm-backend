package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Country;

public interface ICountryService {
    Country createCountry(String name, String code);
    Country updateCountry(Long id, String name, String code) throws DataNotFoundException;
    void deleteCountry(Long id) throws InvalidDataException;
}
