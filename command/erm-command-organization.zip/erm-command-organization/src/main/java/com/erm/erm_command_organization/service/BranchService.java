package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Address;
import com.erm.erm_command_organization.model.Branch;
import com.erm.erm_command_organization.model.Company;
import com.erm.erm_command_organization.repository.AddressRepository;
import com.erm.erm_command_organization.repository.BranchRepository;
import com.erm.erm_command_organization.repository.CompanyRepository;
import com.erm.erm_command_organization.util.AuditorAwareImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BranchService implements IBranchService {

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private AuditorAware auditor;

    @Override
    public Branch createBranch(String branchName, String branchDescription, String type, Long addressId, Long companyId) throws InvalidDataException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Address address = getAddress(addressId);
        Company company = getCompany(companyId);

        Branch branch = new Branch();
        branch.setName(branchName);
        branch.setDescription(branchDescription);
        branch.setType(type);
        branch.setAddress(address);
        branch.setCompany(company);
        branch.setClientIP(clientIp);
        return branchRepository.save(branch);
    }

    @Override
    public Branch updateBranch(Long id, String branchName, String branchDescription, String type, Long addressId, Long companyId) throws DataNotFoundException, InvalidDataException {
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();

        Optional<Branch> branchOptional = branchRepository.findById(id);
        if(branchOptional.isEmpty()){
            throw new DataNotFoundException("Branch not found!");
        }
        Branch branch = branchOptional.get();

        Address address = getAddress(addressId);
        Company company = getCompany(companyId);

        branch.setName(branchName);
        branch.setDescription(branchDescription);
        branch.setType(type);
        branch.setAddress(address);
        branch.setCompany(company);
        branch.setClientIP(clientIp);
        return branchRepository.save(branch);
    }

    @Override
    public void deleteBranch(Long id) throws InvalidDataException {
        Optional<Branch> branchOptional = branchRepository.findById(id);
        if(branchOptional.isEmpty()){
            throw new InvalidDataException("Invalid Branch ID.");
        }
        branchRepository.deleteById(id);
    }

    private Address getAddress(Long id){
        Optional<Address> addressOptional = addressRepository.findById(id);
        if(addressOptional.isEmpty()){
            throw new DataNotFoundException("Invalid Address ID");
        }
        return addressOptional.get();
    }

    private Company getCompany(Long id){
        Optional<Company> companyOptional = companyRepository.findById(id);
        if(companyOptional.isEmpty()){
            throw new DataNotFoundException("Invalid Company ID");
        }
        return companyOptional.get();
    }
}
