package com.erm.erm_command_organization.model.history;

import com.erm.erm_command_organization.model.BaseModel;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class CompanyHistory extends BaseModel {
    private Long companyId;
    private String name;
    private String companyLogoImageUrl;
    private String operation;
}
