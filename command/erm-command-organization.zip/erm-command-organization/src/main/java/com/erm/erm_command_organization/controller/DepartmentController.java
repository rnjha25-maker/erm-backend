package com.erm.erm_command_organization.controller;

import com.erm.erm_command_organization.dto.requestDTO.departmentDTO.AddRequest;
import com.erm.erm_command_organization.dto.requestDTO.departmentDTO.UpdateRequest;
import com.erm.erm_command_organization.dto.responseDTO.GeneralResponse;
import com.erm.erm_command_organization.dto.responseDTO.ResponseStatus;
import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Department;
import com.erm.erm_command_organization.service.IDepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("department")
public class DepartmentController {

    @Autowired
    private IDepartmentService departmentService;

    @PostMapping("/create")
    public GeneralResponse<Department> createDepartment(@RequestBody AddRequest request) {
        GeneralResponse<Department> response = new GeneralResponse<>();
        Department department = departmentService.createDepartment(request.getName(), request.getDescription());
        response.setData(department);
        response.setStatus(ResponseStatus.SUCCESS);
        response.setMessage("Department created!");
        return response;
    }

    @PutMapping("/update")
    public GeneralResponse<Department> updateDepartment(@RequestBody UpdateRequest request) {
        GeneralResponse<Department> response = new GeneralResponse<>();
        try{
            Department department = departmentService.updateDepartment(request.getId(), request.getName(), request.getDescription());
            response.setData(department);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Department updated!");
        }catch (DataNotFoundException e){
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }

    @DeleteMapping("/{id:[\\d]+}")
    public GeneralResponse<Department> deleteDepartment(@PathVariable Long id) {
        GeneralResponse<Department> response = new GeneralResponse<>();
        try{
            departmentService.deleteDepartment(id);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Department deleted!");
        }catch (InvalidDataException e){
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }
}
