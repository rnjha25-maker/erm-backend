package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Company;
import com.erm.erm_command_organization.repository.CompanyRepository;
import com.erm.erm_command_organization.util.AuditorAwareImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CompanyService implements ICompanyService {

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private AuditorAware auditor;

    @Override
    public Company createCompany(String companyName, String companyImgUrl){
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Company company = new Company();
        company.setName(companyName);
        company.setCompanyLogoImageUrl(companyImgUrl);
        company.setClientIP(clientIp);
        return companyRepository.save(company);
    }

    @Override
    public Company updateCompany(Long id, String companyName, String companyImgUrl) throws DataNotFoundException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Optional<Company> companyOptional = companyRepository.findById(id);
        if(companyOptional.isEmpty()){
            throw new DataNotFoundException("Company not found!");
        }
        Company company = companyOptional.get();
        company.setName(companyName);
        company.setCompanyLogoImageUrl(companyImgUrl);
        company.setClientIP(clientIp);
        return companyRepository.save(company);
    }

    @Override
    public void deleteCompany(Long id) throws InvalidDataException {
        Optional<Company> companyOptional = companyRepository.findById(id);
        if(companyOptional.isEmpty()){
            throw new InvalidDataException("Invalid Company ID.");
        }
        companyRepository.deleteById(id);
    }
}
