package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.City;
import com.erm.erm_command_organization.model.State;
import com.erm.erm_command_organization.repository.CityRepository;
import com.erm.erm_command_organization.repository.StateRepository;
import com.erm.erm_command_organization.util.AuditorAwareImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CityService implements ICityService {

    @Autowired
    private CityRepository cityRepository;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private AuditorAware auditor;

    @Override
    public City createCity(String name, Long StateId) throws InvalidDataException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();

        Optional<State> stateOptional = stateRepository.findById(StateId);
        if(stateOptional.isEmpty()){
            throw new InvalidDataException("Invalid State ID");
        }
        State state = stateOptional.get();

        City city = new City();
        city.setName(name);
        city.setState(state);
        city.setClientIP(clientIp);
        return cityRepository.save(city);
    }

    @Override
    public City updateCity(Long id, String name, Long StateId) throws DataNotFoundException, InvalidDataException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();

        Optional<City> cityOptional = cityRepository.findById(id);
        if(cityOptional.isEmpty()){
            throw new DataNotFoundException("City not found");
        }
        City city = cityOptional.get();

        Optional<State> stateOptional = stateRepository.findById(StateId);
        if(stateOptional.isEmpty()){
            throw new InvalidDataException("Invalid State ID");
        }
        State state = stateOptional.get();

        city.setName(name);
        city.setState(state);
        city.setClientIP(clientIp);
        return cityRepository.save(city);
    }

    @Override
    public void deleteCity(Long id) throws InvalidDataException{
        Optional<City> cityOptional = cityRepository.findById(id);
        if(cityOptional.isEmpty()){
            throw new InvalidDataException("Invalid City ID");
        }
        cityRepository.deleteById(id);
    }
}
