package com.erm.erm_command_organization.repository;

import com.erm.erm_command_organization.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    Department save(Department department);
}
