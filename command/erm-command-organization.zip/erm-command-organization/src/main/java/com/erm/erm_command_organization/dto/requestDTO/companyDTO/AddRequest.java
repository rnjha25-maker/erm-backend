package com.erm.erm_command_organization.dto.requestDTO.companyDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddRequest {
    private String name;
    private String companyLogoImageUrl;
}
