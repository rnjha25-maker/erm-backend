package com.erm.erm_command_organization.repository;

import com.erm.erm_command_organization.model.State;
import org.springframework.data.repository.CrudRepository;

public interface StateRepository extends CrudRepository<State, Long> {
    State save(State state);
}
