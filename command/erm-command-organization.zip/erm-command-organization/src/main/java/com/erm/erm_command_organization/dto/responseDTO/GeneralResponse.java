package com.erm.erm_command_organization.dto.responseDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GeneralResponse<T> {
	private T data;
	private String message;
	private ResponseStatus status;
}
