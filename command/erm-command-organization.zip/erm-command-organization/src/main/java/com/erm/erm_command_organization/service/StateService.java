package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Country;
import com.erm.erm_command_organization.model.State;
import com.erm.erm_command_organization.repository.CountryRepository;
import com.erm.erm_command_organization.repository.StateRepository;
import com.erm.erm_command_organization.util.AuditorAwareImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StateService implements IStateService {

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private AuditorAware auditor;

    @Override
    public State createState(String name, Long countryId) throws InvalidDataException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();

        Optional<Country> countryOptional = countryRepository.findById(countryId);
        if(countryOptional.isEmpty()){
            throw new InvalidDataException("Invalid Country ID");
        }
        Country country = countryOptional.get();

        State state = new State();
        state.setName(name);
        state.setCountry(country);
        state.setClientIP(clientIp);
        return stateRepository.save(state);
    }

    @Override
    public State updateState(Long id, String name, Long countryId) throws DataNotFoundException, InvalidDataException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();

        Optional<State> stateOptional = stateRepository.findById(id);
        if(stateOptional.isEmpty()){
            throw new DataNotFoundException("State not found");
        }
        State state = stateOptional.get();

        Optional<Country> countryOptional = countryRepository.findById(countryId);
        if(countryOptional.isEmpty()){
            throw new InvalidDataException("Invalid Country ID");
        }
        Country country = countryOptional.get();

        state.setName(name);
        state.setCountry(country);
        state.setClientIP(clientIp);
        return stateRepository.save(state);
    }

    @Override
    public void deleteState(Long id) throws InvalidDataException{
        Optional<State> stateOptional = stateRepository.findById(id);
        if(stateOptional.isEmpty()){
            throw new InvalidDataException("Invalid State ID");
        }
        stateRepository.deleteById(id);
    }
}
