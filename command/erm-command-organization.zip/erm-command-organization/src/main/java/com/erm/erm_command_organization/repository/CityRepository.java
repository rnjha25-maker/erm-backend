package com.erm.erm_command_organization.repository;

import com.erm.erm_command_organization.model.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepository extends JpaRepository<City, Long> {
    City save(City city);
}
