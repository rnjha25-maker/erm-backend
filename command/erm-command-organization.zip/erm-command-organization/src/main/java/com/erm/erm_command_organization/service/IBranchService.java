package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Branch;

public interface IBranchService {
    Branch createBranch(String branchName, String branchDescription, String type, Long addressId, Long companyId) throws InvalidDataException;
    Branch updateBranch(Long id, String branchName, String branchDescription, String type, Long addressId, Long companyId) throws DataNotFoundException, InvalidDataException;
    void deleteBranch(Long id) throws InvalidDataException;
}
