package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Organization;

public interface IOrganizationService {
    Organization createOrganization(String orgName, String orgImgUrl);
    Organization updateOrganization(Long id, String orgName, String orgImgUrl) throws DataNotFoundException;
    void deleteOrganization(Long id) throws InvalidDataException;
}
