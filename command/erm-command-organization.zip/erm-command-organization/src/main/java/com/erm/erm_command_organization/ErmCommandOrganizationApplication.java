package com.erm.erm_command_organization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErmCommandOrganizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErmCommandOrganizationApplication.class, args);
	}

}
