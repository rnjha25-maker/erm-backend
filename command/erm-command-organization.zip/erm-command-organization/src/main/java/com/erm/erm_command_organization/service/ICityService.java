package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.City;

public interface ICityService {
    City createCity(String name, Long StateId) throws InvalidDataException;
    City updateCity(Long id, String name, Long StateId) throws DataNotFoundException, InvalidDataException;
    void deleteCity(Long id) throws InvalidDataException;
}
