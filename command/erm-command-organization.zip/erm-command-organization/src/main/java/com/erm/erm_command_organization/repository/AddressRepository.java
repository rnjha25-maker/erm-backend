package com.erm.erm_command_organization.repository;

import com.erm.erm_command_organization.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
    Address save(Address address);
}
