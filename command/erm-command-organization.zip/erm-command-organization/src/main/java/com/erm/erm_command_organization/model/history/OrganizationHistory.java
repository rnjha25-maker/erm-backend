package com.erm.erm_command_organization.model.history;

import com.erm.erm_command_organization.model.BaseModel;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class OrganizationHistory extends BaseModel {
    private Long organizationId;
    private String name;
    private String organizationLogoImageUrl;
    private String operation;
}
