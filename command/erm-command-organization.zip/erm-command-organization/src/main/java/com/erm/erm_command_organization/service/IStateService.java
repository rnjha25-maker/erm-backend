package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.State;

public interface IStateService {
    State createState(String name, Long countryId) throws InvalidDataException;
    State updateState(Long id, String name, Long countryId) throws DataNotFoundException, InvalidDataException;
    void deleteState(Long id) throws InvalidDataException;
}