package com.erm.erm_command_organization.repository;

import com.erm.erm_command_organization.model.Country;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CountryRepository extends JpaRepository<Country, Long> {
    Country save(Country country);
}
