package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Department;

public interface IDepartmentService {
    Department createDepartment(String deptName, String deptDescription);
    Department updateDepartment(Long id, String deptName, String deptDescription) throws DataNotFoundException;
    void deleteDepartment(Long id) throws InvalidDataException;
}
