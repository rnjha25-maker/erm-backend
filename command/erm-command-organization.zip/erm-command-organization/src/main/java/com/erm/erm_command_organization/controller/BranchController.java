package com.erm.erm_command_organization.controller;

import com.erm.erm_command_organization.dto.requestDTO.branchDTO.AddRequest;
import com.erm.erm_command_organization.dto.requestDTO.branchDTO.UpdateRequest;
import com.erm.erm_command_organization.dto.responseDTO.GeneralResponse;
import com.erm.erm_command_organization.dto.responseDTO.ResponseStatus;
import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Branch;
import com.erm.erm_command_organization.service.IBranchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("branch")
public class BranchController {
    @Autowired
    private IBranchService branchService;

    @PostMapping("/create")
    public GeneralResponse<Branch> createBranch(@RequestBody AddRequest request) {
        GeneralResponse<Branch> response = new GeneralResponse<>();
        Branch branch = branchService.createBranch(request.getName(), request.getDescription(), request.getType(), request.getAddressId(), request.getCompanyId());
        response.setData(branch);
        response.setStatus(ResponseStatus.SUCCESS);
        response.setMessage("Branch created!");
        return response;
    }

    @PutMapping("/update")
    public GeneralResponse<Branch> updateBranch(@RequestBody UpdateRequest request) {
        GeneralResponse<Branch> response = new GeneralResponse<>();
        try{
            Branch branch = branchService.updateBranch(request.getId(), request.getName(), request.getDescription(), request.getType(), request.getAddressId(), request.getCompanyId());
            response.setData(branch);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Branch updated!");
        }catch (DataNotFoundException e){
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }

    @DeleteMapping("/{id:[\\d]+}")
    public GeneralResponse<Void> deleteBranch(@PathVariable Long id) {
        GeneralResponse<Void> response = new GeneralResponse<>();
        try{
            branchService.deleteBranch(id);
            response.setStatus(ResponseStatus.SUCCESS);
            response.setMessage("Branch deleted!");
        }catch (InvalidDataException e){
            response.setStatus(ResponseStatus.FAILED);
            response.setMessage(e.getMessage());
        }
        return response;
    }
}
