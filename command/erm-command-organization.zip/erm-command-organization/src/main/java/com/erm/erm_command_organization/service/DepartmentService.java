package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Department;
import com.erm.erm_command_organization.repository.DepartmentRepository;
import com.erm.erm_command_organization.util.AuditorAwareImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DepartmentService implements IDepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private AuditorAware auditor;

    @Override
    public Department createDepartment(String deptName, String deptDescription){
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Department department = new Department();
        department.setName(deptName);
        department.setDescription(deptDescription);
        department.setClientIP(clientIp);
        return departmentRepository.save(department);
    }

    @Override
    public Department updateDepartment(Long id, String deptName, String deptDescription) throws DataNotFoundException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Optional<Department> departmentOptional = departmentRepository.findById(id);
        if(departmentOptional.isEmpty()){
            throw new DataNotFoundException("Invalid Department ID.");
        }
        Department department = departmentOptional.get();
        department.setName(deptName);
        department.setDescription(deptDescription);
        department.setClientIP(clientIp);
        return departmentRepository.save(department);
    }

    @Override
    public void deleteDepartment(Long id) throws InvalidDataException {
        Optional<Department> departmentOptional = departmentRepository.findById(id);
        if(departmentOptional.isEmpty()){
            throw new InvalidDataException("Invalid Department ID.");
        }
        departmentRepository.deleteById(id);
    }
}
