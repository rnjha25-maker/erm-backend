package com.erm.erm_command_organization.service;

import com.erm.erm_command_organization.exception.DataNotFoundException;
import com.erm.erm_command_organization.exception.InvalidDataException;
import com.erm.erm_command_organization.model.Organization;
import com.erm.erm_command_organization.repository.OrganizationRepository;
import com.erm.erm_command_organization.util.AuditorAwareImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OrganizationService implements IOrganizationService {
    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private AuditorAware auditor;

    @Override
    public Organization createOrganization(String orgName, String orgImgUrl){
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Organization organization = new Organization();
        organization.setName(orgName);
        organization.setOrganizationLogoImageUrl(orgImgUrl);
        organization.setClientIP(clientIp);
        return organizationRepository.save(organization);
    }

    @Override
    public Organization updateOrganization(Long id, String orgName, String orgImgUrl) throws DataNotFoundException{
        String clientIp = ((AuditorAwareImpl) auditor).getClientIp();
        Optional<Organization> organizationOptional = organizationRepository.findById(id);
        if(organizationOptional.isEmpty()){
            throw new DataNotFoundException("Organization not found!");
        }
        Organization organization = organizationOptional.get();
        organization.setName(orgName);
        organization.setOrganizationLogoImageUrl(orgImgUrl);
        organization.setClientIP(clientIp);
        return organizationRepository.save(organization);
    }

    @Override
    public void deleteOrganization(Long id) throws InvalidDataException {
        Optional<Organization> organizationOptional = organizationRepository.findById(id);
        if(organizationOptional.isEmpty()){
            throw new InvalidDataException("Invalid Organization ID.");
        }
        organizationRepository.deleteById(id);
    }
}
